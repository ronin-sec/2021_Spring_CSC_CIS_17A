/* 
 * File:        	main.cpp
 * Author:      	Antero Avalos
 * Date Created:    	02/20/21 11:10 am
 * Date Finished:       02/20/21 
 * Purpose:     	Hello World Output 
 */

//System Libraries
#include <iostream>  //I/O Library

using namespace std;

int main(int argc, char** argv) {
    
    //Output hello world
    cout << "Hello World" << endl; 
    
    return 0;
}